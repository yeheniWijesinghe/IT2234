//array of student JSON details
let students = [
    {regno:'2021ict01',name:'Yeheni',gender:'Female',course:'IT'},
    {regno:'2021ict02',name:'Sashini',gender:'Female',course:'IT'},
    {regno:'2021ict03',name:'Nipunika',gender:'Female',course:'IT'},
    {regno:'2021ict04',name:'Ushani',gender:'Female',course:'IT'},
    {regno:'2021ict05',name:'Ridmi',gender:'Female',course:'IT'},
    {regno:'2021ict06',name:'Ravindu',gender:'Male',course:'IT'},
    {regno:'2021ict07',name:'Samodya',gender:'Female',course:'IT'},
    {regno:'2021ict08',name:'Nimsilu',gender:'Male',course:'IT'}
]

module.exports = students;