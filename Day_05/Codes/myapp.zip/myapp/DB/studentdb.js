//array of student JSON details
let students = [
    {regno:'2021ict01',name:'Yeheni',gender:'F',course:'IT'},
    {regno:'2021ict02',name:'Sashini',gender:'F',course:'IT'},
    {regno:'2021ict03',name:'Nipunika',gender:'F',course:'IT'},
    {regno:'2021ict04',name:'Ushani',gender:'F',course:'IT'},
    {regno:'2021ict05',name:'Ridmi',gender:'F',course:'IT'},
    {regno:'2021ict06',name:'Ravindu',gender:'M',course:'IT'},
    {regno:'2021ict07',name:'Samodya',gender:'F',course:'IT'},
    {regno:'2021ict08',name:'Nimsilu',gender:'M',course:'IT'}
]

module.exports = students;